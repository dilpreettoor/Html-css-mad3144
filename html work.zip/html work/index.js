
var context = document.getElementById("draw").getContext("2d");
context.lineWidth = 10;
context.strokeStyle = "#0000FF";
context.lineJoin = "round";

var mainCanvas = document.getElementById("draw");
startDrawing = false;

//detect if its a click
//detect a click
mainCanvas.addEventListener("mousedown", function() {
  isClick = 0;
  startDrawing = true;

});
mainCanvas.addEventListener("mouseup", function(e) {
  startDrawing = false;
  //detect the different between a click & the end of a drag
  if (isClick == 0) {
    console.log("person is clicking");

    //insert code to draw a rectangle
    var rect = mainCanvas.getBoundingClientRect();
    var x = e.pageX  - rect.left;
    var y = e.pageY - rect.top;

    context.fillRect(x,y, context.lineWidth, context.lineWidth);

  }
    else if (isClick == 1) {
      console.log("person is dragging");
      context.beginPath();
    }


});
// new button
document.getElementById("new").addEventListener("click", function(){
  context.clearRect(0,0, mainCanvas.width, mainCanvas.height);
});
//erase button

document.getElementById("erase").addEventListener("click",function(){
  context.strokeStyle="#ffffff"
});

//red button
document.getElementById("red").addEventListener("click",function(){
  context.strokeStyle="#ff0000"
});

//red button
document.getElementById("pink").addEventListener("click",function(){
  context.strokeStyle="#ff00ff"
});

//blue button
document.getElementById("blue").addEventListener("click",function(){
  context.strokeStyle="#0000ff"
});

//change brush Size
document.getElementById("slider").addEventListener("change",function(){
  //logic
  var sliderValue = this.value;
  console.log(sliderValue);

  //ui
  context.lineWidth = sliderValue;
  document.getElementById("brushSize").innerHTML = sliderValue;
});


  //console.log("moving");
  mainCanvas.addEventListener("mousemove", function(e) {
    isClick = 1;
    if (startDrawing == true) {
    var rect = mainCanvas.getBoundingClientRect();
  var x = e.pageX  - rect.left;
  var y = e.pageY - rect.top;

    context.fillStyle = "#000000";
    context.lineTo(x,y);
    context.closePath();
    context.stroke();

    context.moveTo(x,y);
  }
});


mainCanvas.addEventListener("mouseleave", function() {
  console.log("leaving the canvas");
//startDrawing = false;
});

mainCanvas.addEventListener("mouseenter", function() {
  console.log("entering the canvas");
startDrawing = true;
context.beginPath();
});
